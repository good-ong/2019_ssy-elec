<?php
require_once('fixview/fix_top_and_ltside.php');
?>
상품 세부정보 화면입니다. <br>
<img src="./h_img/test.gif">
<?php
require_once('fixview/fix_bottom.php');
?>
