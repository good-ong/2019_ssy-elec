                    </td>
                    <!--변동화면 끝-->
                  </tr>
                </table>
              </td>
            </tr>
            <tr>
              <td height="30">&nbsp;</td>
            </tr>
          </table>
        </td>
      </tr>
    </table>
    <!--메인 끝 (작업중)-->

    <!--하단 사업정보 시작 (작업중)-->
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td height="50">&nbsp;</td>
      </tr>
      <tr>
        <td align="center" height="40" bgcolor="#3F0000"></td>
      </tr>
      <tr>
        <td align="center" bgcolor="#BDBDBD">
          <table width="1000" border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td height="25">&nbsp;</td>
            </tr>
            <tr>
              <td width="300" align="center">
                <a href="home.php">
                  <img src="./h_img/logo.gif" width="290" height="120">
                </a>
              </td>
              <td align="left" style="font-size:12px;">
                상호명 : 쌍용전기&nbsp;&nbsp;|&nbsp;&nbsp;대표 : 조정연&nbsp;&nbsp;|&nbsp;&nbsp;대표전화 : 051)319-3444, 010-3422-2144<br>
                팩스 : 051)319-3443&nbsp;&nbsp;|&nbsp;&nbsp;주소 : 부산광역시 사상구 괘감로 37, 1동 113호<br>
                사업자등록번호 : 332-08-00989 &nbsp;&nbsp;|&nbsp;&nbsp;
                통신판매업신고 : 제2019-사상구-0036호<a href='#none' onclick="window.open('http://www.ftc.go.kr/info/bizinfo/communicationViewPopup.jsp?wrkr_no=3320800989','ftc','location=no,directories=no,resizable=no,status=no,toolbar=no,scrollbars,width=750,height=700,top=100,left=150')" style="font-size:13px">(정보확인)</a> <br><br>
                사이트담당자 : 김규동, 김태연 </br>개인정보관리 및 정보책임자 : 김규동, 김태연&nbsp;&nbsp;|&nbsp;&nbsp;
                E-mail : rbehd6129@gmail.com / xovkf0962@naver.com<br><br>
                Copyright ⓒ 2019. 쌍용전기  All right reserved.
              </td>
            </tr>
          </table>
        </td>
      </tr>
      <tr>
        <td height="30" bgcolor="#BDBDBD"></td>
      </tr>
    </table>
    <!--하단 사업정보 끝 (작업중)-->
  </body>
</html>
