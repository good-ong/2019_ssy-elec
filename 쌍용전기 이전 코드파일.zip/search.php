<?php
require_once('fixview/fix_top_and_ltside.php');
?>
<table border="0" width="750" cellspacing="0" cellpadding="0">
  <tr>
    <td>
      <img src="./h_img/s_icon.gif" width="300">
    </td>
  </tr>
  <tr>
    <td colspan="4" height="40">
      <?php echo "<strong>'".$_GET['s_str']."'</strong> 에 대한 검색결과입니다."; ?>
    </td>
  </tr>
  <tr>
    <td height="40" style="background:#810000"></td>
  </tr>
  <tr>
    <td><img src="./h_img/test.gif"></td>
  </tr>
</table>
<?php
require_once('fixview/fix_bottom.php');
?>
