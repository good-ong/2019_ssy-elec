<?php
require_once('fixview/fix_top_and_ltside.php');
?>

<img src="h_img/buy_notice.gif" width="600">
<?php
require_once('fixview/fix_bottom.php');
?>
