<?php
require_once('fixview/fix_top_and_ltside.php');
?>

<table border="0" cellspacing="0" cellpadding="0">
  <tr height="40"><td></td></tr>
  <tr valign="top">
    <td>
      <table border="0" width="750" cellspacing="0" cellpadding="0">
        <!--카테고리 1의 상품 4개 시작-->
        <tr valign="center" height="40" bgcolor="#810000">
          <td colspan="2" align="left">
            <a href="m_list.php?cate=01"><img src="h_img/side_category/side1.gif"></a>
          </td>
          <td colspan="2" align="right">
            <a href="m_list.php?cate=01"><img src="h_img/main_title_more.gif"></a>
          </td>
        </tr>
        <tr align="center" valign="center"><td colspan="4" height="20"></td></tr>
        <tr align="center" align="center" valign="center">
          <td><a class="item_name" name="it_01" href="m_list_detail.php"><img class="it_img_file" src="./it_img/01/01_ts_130.jpg"><br>TS<br><strong>목록단가확인</strong></a></td>
          <td><a class="item_name" name="it_01" href="m_list_detail.php"><img class="it_img_file" src="./it_img/01/02_tc_130.jpg"><br>TC(베이스,지붕별도)<br><strong>목록단가확인</strong></a></td>
          <td><a class="item_name" name="it_01" href="m_list_detail.php"><img class="it_img_file" src="./it_img/01/03_td_130.jpg"><br>TD(P-COVER)<br><strong>목록단가확인</strong></a></td>
          <td><a class="item_name" name="it_01" href="m_list_detail.php"><img class="it_img_file" src="./it_img/01/04_tr_130.jpg"><br>TR(베이스 별도)<br><strong>목록단가확인</strong></a></td>
        </tr>
        <tr align="center" valign="center"><td colspan="4" height="20"></td></tr>
        <!--카테고리 1의 상품 4개 끝-->
        <!--카테고리 2의 상품 4개 시작-->
        <tr valign="center" height="40" bgcolor="#810000">
          <td colspan="2" align="left">
            <a href="m_list.php?cate=02"><img src="h_img/side_category/side2.gif"></a>
          </td>
          <td colspan="2" align="right">
            <a href="m_list.php?cate=02"><img src="h_img/main_title_more.gif"></a>
          </td>
        </tr>
        <tr align="center" valign="center"><td colspan="4" height="20"></td></tr>
        <tr align="center" align="center" valign="center">
          <td><a class="item_name" name="it_02" href="m_list_detail.php"><img class="it_img_file" src="./it_img/02/01_tsd_130.jpg"><br>TSD(경제형 SUS박스)<br><strong>목록단가확인</strong></a></td>
          <td><a class="item_name" name="it_02" href="m_list_detail.php"><img class="it_img_file" src="./it_img/02/02_tsd_130.jpg"><br>TSD(옥내 SUS박스)<br><strong>목록단가확인</strong></a></td>
          <td><a class="item_name" name="it_02" href="m_list_detail.php"><img class="it_img_file" src="./it_img/02/03_tsod_130.jpg"><br>TSOD(옥외 SUS박스)<br><strong>목록단가확인</strong></a></td>
          <td><a class="item_name" name="it_02" href="m_list_detail.php"><img class="it_img_file" src="./it_img/02/04_tsl_130.jpg"><br>TSL LOCAL<br><strong>목록단가확인</strong></a></td>
        </tr>
        <tr align="center" valign="center"><td colspan="4" height="20"></td></tr>
        <!--카테고리 2의 상품 4개 끝-->
        <!--카테고리 3의 상품 4개 시작-->
        <tr valign="center" height="40" bgcolor="#810000">
          <td colspan="2" align="left">
            <a href="m_list.php?cate=03"><img src="h_img/side_category/side3.gif"></a>
          </td>
          <td colspan="2" align="right">
            <a href="m_list.php?cate=03"><img src="h_img/main_title_more.gif"></a>
          </td>
        </tr>
        <tr align="center" valign="center"><td colspan="4" height="20"></td></tr>
        <tr align="center" align="center" valign="center">
          <td><a class="item_name" name="it_03" href="m_list_detail.php"><img class="it_img_file" src="it_img/03/31/s135.png"><br>노출형 - s135<br><strong>목록단가확인</strong></a></td>
          <td><a class="item_name" name="it_03" href="m_list_detail.php"><img class="it_img_file" src="it_img/03/31/s136.png"><br>노출형 - s136<br><strong>목록단가확인</strong></a></td>
          <td><a class="item_name" name="it_03" href="m_list_detail.php"><img class="it_img_file" src="it_img/03/32/s126.png"><br>주택용 - s126<br><strong>목록단가확인</strong></a></td>
          <td><a class="item_name" name="it_03" href="m_list_detail.php"><img class="it_img_file" src="it_img/03/32/s127.png"><br>주택용 - s127<br><strong>목록단가확인</strong></a></td>
        </tr>
        <tr align="center" valign="center"><td colspan="4" height="20"></td></tr>
        <!--카테고리 3의 상품 4개 끝-->
        <!--카테고리 4의 상품 4개 시작-->
        <tr valign="center" height="40" bgcolor="#810000">
          <td colspan="2" align="left">
            <a href="m_list.php?cate=04"><img src="h_img/side_category/side4.gif"></a>
          </td>
          <td colspan="2" align="right">
            <a href="m_list.php?cate=04"><img src="h_img/main_title_more.gif"></a>
          </td>
        </tr>
        <tr align="center" valign="center"><td colspan="4" height="20"></td></tr>
        <tr align="center" align="center" valign="center">
          <td><a class="item_name" name="it_04" href="m_list_detail.php"><img class="it_img_file" src="it_img/04/jp01_130.jpg"><br>JP1<br><strong>목록단가확인</strong></a></td>
          <td><a class="item_name" name="it_04" href="m_list_detail.php"><img class="it_img_file" src="it_img/04/jp02_130.jpg"><br>JP2<br><strong>목록단가확인</strong></a></td>
          <td><a class="item_name" name="it_04" href="m_list_detail.php"><img class="it_img_file" src="it_img/04/jp03_130.jpg"><br>JP3<br><strong>목록단가확인</strong></a></td>
          <td><a class="item_name" name="it_04" href="m_list_detail.php"><img class="it_img_file" src="it_img/04/jp04_130.jpg"><br>JP4<br><strong>목록단가확인</strong></a></td>
        </tr>
        <tr align="center" valign="center"><td colspan="4" height="20"></td></tr>
        <!--카테고리 4의 상품 4개 끝-->
      </table>
    </td>
  </tr>
</table>
<?php
require_once('fixview/fix_bottom.php');
?>
