<?php
$user_temper = $_POST['re_user_temper'];
$user_adr = $_POST['re_user_adr'];
$user_phone = $_POST['re_user_phone'];
?>
<meta http-equiv='refresh' content='0;url=my_log.php'>
